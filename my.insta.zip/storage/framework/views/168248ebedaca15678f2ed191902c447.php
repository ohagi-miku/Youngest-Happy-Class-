

<?php $__env->startSection('title', 'Admin: Users'); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-hover align-middle bg-white border text-secondary">
        <thead class="small table-success text-secondary">
            <tr>
                <th></th>
                <th>NAME</th>
                <th>EMAIL</th>
                <th>CREATE AT</th>
                <th>STATUS</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($user->avatar): ?>
                            <img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->name); ?>"
                                class="rounded-circle d-block mx-auto avatar-md">
                        <?php else: ?>
                            <i class="fa-solid fa-circle-user d-block text-center icon-md mx-auto"></i>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('profile.show', $user->id)); ?>"
                            class="text-decoration-none text-dark fw-bold"><?php echo e($user->name); ?>

                        </a>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    <td>
                        <?php if($user->trashed()): ?>
                            
                            <i class="fa-regular fa-circle text-secondary"></i> &nbsp; Inactive
                        <?php else: ?>
                            <i class="fa-solid fa-circle text-success"></i> &nbsp; Active
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(Auth::user()->id !== $user->id): ?>
                            <div class="dropdown">
                                <button class="btn btn-sm" data-bs-toggle="dropdown">
                                    <i class="fa-solid fa-ellipsis"></i>
                                </button>

                                <div class="dropdown-menu">
                                    <?php if($user->trashed()): ?>
                                        <button class="dropdown-item" data-bs-toggle="modal"
                                        data-bs-target="#activate-user-<?php echo e($user->id); ?>">
                                            <i class="fa-solid fa-user-check"></i> Activate <?php echo e($user->name); ?>

                                        </button>
                                        
                                    <?php else: ?>
                                        <button class="dropdown-item text-danger" data-bs-toggle="modal"
                                            data-bs-target="#deactivate-user-<?php echo e($user->id); ?>">
                                            <i class="fa-solid fa-user slash"></i> Deactivate <?php echo e($user->name); ?>

                                        </button>
                                        
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <?php echo $__env->make('admin.users.modals.status', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endif; ?>
                    </td>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-center">
        <?php echo e($all_users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bfmik\Desktop\dev3-laravel\laravel-insta\resources\views/admin/users/index.blade.php ENDPATH**/ ?>