<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
</head>
<body>
    <p>Hello <?php echo e($name); ?></p>
    <p>Thank you for registering</p>
    <p>To start, please access the website <a href="<?php echo e($app_url); ?>">here</a>.</p>
    <p>Thank you!</p>
</body>
</html><?php /**PATH C:\Users\bfmik\Desktop\dev3-laravel\laravel-insta\resources\views/users/emails/welcome.blade.php ENDPATH**/ ?>