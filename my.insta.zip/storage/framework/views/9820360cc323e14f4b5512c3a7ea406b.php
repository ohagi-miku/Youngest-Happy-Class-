

<?php $__env->startSection('title', 'Admin: Posts'); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-hover align-middle bg-white border text-secondary">
        <thead class="small table-primary text-secondary">
            <tr>
                <th></th>
                <th></th>
                <th>CATEGORY</th>
                <th>OWNER</th>
                <th>CREATED AT</th>
                <th>STATUS</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $all_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td>
                        <?php if($post->image): ?>
                            <img src="<?php echo e($post->image); ?>" alt="post id <?php echo e($post->id); ?>" class="d-block mx-auto"
                                style="width: 130px; height: 110px; object-fit: cover;">
                        <?php else: ?>
                            <i class="fa-solid fa-image d-block text-center icon-md mx-auto"></i>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php $__currentLoopData = $post->categoryPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary bg-opacity-50">
                                <?php echo e($cp->category->name); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <?php echo e($post->user->name); ?>

                    </td>
                    <td><?php echo e($post->created_at); ?></td>
                    <td>
                        <?php if($post->trashed()): ?>
                            <i class="fa-solid fa-circle-minus text-secondary"></i> &nbsp; Hidden
                        <?php else: ?>
                            <i class="fa-solid fa-circle text-primary"></i> &nbsp; Visible
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-sm" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-ellipsis"></i>
                            </button>

                            <div class="dropdown-menu">
                                <?php if($post->trashed()): ?>
                                    <button class="dropdown-item" data-bs-toggle="modal"
                                        data-bs-target="#unhide-post-<?php echo e($post->id); ?>">
                                        <i class="fa-solid fa-eye"></i> Unhide Post <?php echo e($post->id); ?>

                                    </button>
                                <?php else: ?>
                                    <button class="dropdown-item" data-bs-toggle="modal"
                                        data-bs-target="#hide-post-<?php echo e($post->id); ?>">
                                        <i class="fa-solid fa-eye-slash"></i> Hide Post <?php echo e($post->id); ?>

                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php echo $__env->make('admin.posts.modals.status', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-center">
        <?php echo e($all_posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bfmik\Desktop\dev3-laravel\laravel-insta\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>