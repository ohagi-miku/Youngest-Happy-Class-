
<div class="modal fade" id="delete-category-<?php echo e($category->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content border-danger">
            <div class="modal-header border-danger">
                <h3 class="h5 modal-title text-danger">
                    <i class="fa-solid fa-trash-can"></i> Delete Category
                </h3>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete  <span class="fw-bold text-dark">"<?php echo e($category->name); ?>"</span> category? <p>
                <p class="small mb-0">
                    This action will affectall the posts under this category. Posts without a category will fall under Uncategorized.
                </p>
            </div>
            <div class="modal-footer border-0">
                
                <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="button" class="btn btn-outline-danger btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="edit-category-<?php echo e($category->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content border-warning">
            <div class="modal-header border-warning">
                <h3 class="h5 modal-title text-warning">
                    <i class="fa-solid fa-pen"></i> Edit Category
                </h3>
            </div>
            
            <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <div class="modal-body">
                    <label for="category-name-<?php echo e($category->id); ?>" class="form-label"></label>
                    
                    <input type="text" name="name" id="category-name-<?php echo e($category->id); ?>" 
                        class="form-control" value="<?php echo e($category->name); ?>" required>
                </div>
                
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-outline-warning btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning btn-sm">Update</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\Users\bfmik\Desktop\dev3-laravel\laravel-insta\resources\views/admin/categories/modals/status.blade.php ENDPATH**/ ?>