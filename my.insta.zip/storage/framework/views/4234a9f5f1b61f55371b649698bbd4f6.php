

<?php $__env->startSection('title', 'Admin: Categories'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.categories.store')); ?>" method="post" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="row g-2 align-items-center">
            <div class="col-sm-4"> 
                <input type="text" name="name" class="form-control" placeholder="Add a category" required autofocus>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Add
                </button>
            </div>
        </div>
    </form>
    <table class="table table-hover align-middle bg-white border text-secondary w-75 text-center">
        <thead class="small table-warning text-secondary">
            <tr>
                <th>#</th>
                <th>NAME</th>
                <th>COUNT</th>
                <th>LAST UPDATE</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($category->id !== 6): ?>
                            <?php echo e($category->id); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($category->name); ?>


                        <?php if($category->id === 6): ?>
                            <div class="text-secondary" style="font-size: 0.75rem;">
                                Hidden posts are not included
                            </div>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($category->categoryPost->count()); ?></td>
                    <td><?php echo e($category->updated_at); ?></td>
                    <td>
                        <?php if($category->id !== 6): ?>
                            <div class="d-flex gap-2 justify-content-end">
                                
                                
                                <button class="btn btn-outline-warning btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#edit-category-<?php echo e($category->id); ?>" title="Edit">
                                    <i class="fa-solid fa-pen"></i>
                                </button>

                                
                                <button class="btn btn-outline-danger btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#delete-category-<?php echo e($category->id); ?>" title="Delete">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>

                            </div>
                        <?php endif; ?>

                        <?php echo $__env->make('admin.categories.modals.status', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-center">
        <?php echo e($all_categories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bfmik\Desktop\dev3-laravel\laravel-insta\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>